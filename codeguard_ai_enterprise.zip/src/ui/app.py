import streamlit as st
import requests
import os
import json

API_URL = os.environ.get("API_URL", "http://localhost:8000")

# Configure the Streamlit app
st.set_page_config(
    page_title="CodeGuard AI Enterprise",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for Vercel/Linear dark theme
def load_custom_css():
    st.markdown("""
        <style>
        /* General dark theme styling */
        .stApp {
            background-color: #000000;
            color: #EDEDED;
            font-family: 'Inter', sans-serif;
        }
        
        /* Headers */
        h1, h2, h3, h4, h5, h6 {
            color: #FFFFFF !important;
            font-weight: 600 !important;
            letter-spacing: -0.02em;
        }
        
        /* Sidebar styling */
        [data-testid="stSidebar"] {
            background-color: #111111;
            border-right: 1px solid #333;
        }
        
        /* Inputs and Textareas */
        .stTextInput > div > div > input, 
        .stTextArea > div > div > textarea {
            background-color: #1A1A1A;
            color: #EDEDED;
            border: 1px solid #333;
            border-radius: 6px;
        }
        .stTextInput > div > div > input:focus, 
        .stTextArea > div > div > textarea:focus {
            border-color: #5E5E5E;
            box-shadow: 0 0 0 1px #5E5E5E;
        }

        /* Buttons */
        .stButton > button {
            background-color: #EDEDED;
            color: #000000;
            border-radius: 6px;
            font-weight: 500;
            border: none;
            transition: all 0.2s ease;
        }
        .stButton > button:hover {
            background-color: #FFFFFF;
            transform: scale(1.02);
        }
        
        /* Specific styling for 'Blocked' / 'Approved' buttons or text could be added here */
        .status-approved {
            color: #10B981 !important; /* Green */
            font-weight: bold;
            font-size: 1.5rem;
        }
        .status-blocked {
            color: #EF4444 !important; /* Red */
            font-weight: bold;
            font-size: 1.5rem;
        }
        
        /* Cards/Containers */
        div[data-testid="stVerticalBlock"] div[style*="flex-direction: column;"] > div[data-testid="stVerticalBlock"] {
            background-color: #111111;
            border: 1px solid #333;
            border-radius: 8px;
            padding: 1rem;
        }
        </style>
    """, unsafe_allow_html=True)

load_custom_css()

def display_login():
    st.title("Login to CodeGuard AI")
    st.markdown("Authenticate via GitHub to access enterprise PR analysis.")
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        username = st.text_input("Enter Username (simulating GitHub login)")
        if st.button("Login with GitHub"):
            try:
                # Simulate Auth
                res = requests.post(f"{API_URL}/auth/login", json={"github_code": "dummy_code"})
                if res.status_code == 200:
                    role_res = requests.post(f"{API_URL}/auth/assign_role", json={"username": username})
                    if role_res.status_code == 200:
                        st.session_state["user"] = role_res.json()
                        st.session_state["token"] = res.json().get("token")
                        st.rerun()
            except Exception as e:
                 st.error(f"Login failed: Could not connect to API at {API_URL}. Error: {e}")

def display_dashboard():
    user = st.session_state.get("user", {})
    st.sidebar.title("CodeGuard AI")
    st.sidebar.markdown(f"**User:** {user.get('username')}")
    st.sidebar.markdown(f"**Role:** {user.get('role')}")
    
    if st.sidebar.button("Logout"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.title("CodeGuard AI Enterprise")
    st.markdown("Analyze Pull Requests with Gemini 2.0 Pro")
    
    with st.form("analyze_form"):
        col1, col2 = st.columns(2)
        with col1:
             repo = st.text_input("GitHub Repository (e.g., owner/repo)", value="owner/repo")
        with col2:
             pr_number = st.number_input("Pull Request Number", min_value=1, value=1)
             
        gh_token = st.text_input("GitHub Token (Optional, for private repos)", type="password")
        gemini_key = st.text_input("Gemini API Key (Required if not in env)", type="password")
        
        submitted = st.form_submit_button("Analyze PR")
        
    if submitted:
        with st.spinner("Analyzing PR with Gemini 2.0 Pro..."):
            try:
                payload = {
                    "repo": repo,
                    "pr_number": pr_number,
                    "github_token": gh_token if gh_token else None,
                    "gemini_key": gemini_key if gemini_key else None
                }
                res = requests.post(f"{API_URL}/analyze", json=payload)
                if res.status_code == 200:
                    data = res.json()
                    st.session_state["analysis_data"] = data
                    st.success("Analysis complete!")
                else:
                    st.error(f"Analysis failed: {res.text}")
            except Exception as e:
                st.error(f"Failed to connect to API: {e}")

    if "analysis_data" in st.session_state:
        data = st.session_state["analysis_data"]
        analysis = data.get("analysis", {})
        
        st.markdown("---")
        
        # Top level metrics
        col_score, col_status, col_download = st.columns(3)
        with col_score:
            st.metric("Score", f"{analysis.get('score', 'N/A')}/100")
            
        with col_status:
            status = analysis.get("status", "N/A")
            status_class = "status-approved" if "APPROVED" in status else "status-blocked"
            st.markdown(f"<div class='{status_class}'>{status}</div>", unsafe_allow_html=True)
            
        with col_download:
            pdf_path = data.get("pdf_report_path")
            if pdf_path and os.path.exists(pdf_path):
                with open(pdf_path, "rb") as pdf_file:
                    st.download_button(
                        label="Download PDF Report",
                        data=pdf_file,
                        file_name=os.path.basename(pdf_path),
                        mime="application/pdf"
                    )
        
        # Tabs for details
        tab1, tab2, tab3, tab4, tab5 = st.tabs(["Comments", "Security", "Performance", "Bugs", "Cost"])
        
        with tab1:
            st.subheader("Line-by-Line Comments")
            for c in analysis.get("comments", []):
                st.markdown(f"**Line {c.get('line', 'N/A')}:** {c.get('comment', '')}")
                
        with tab2:
             st.subheader("Security Vulnerabilities")
             for issue in analysis.get("security_issues", []):
                 st.markdown(f"- {issue}")
                 
        with tab3:
             st.subheader("Performance Issues")
             for issue in analysis.get("performance_issues", []):
                 st.markdown(f"- {issue}")
                 
        with tab4:
             st.subheader("Bugs Detected")
             for issue in analysis.get("bug_issues", []):
                 st.markdown(f"- {issue}")
                 
        with tab5:
             st.subheader("Cost Optimization Issues")
             for issue in analysis.get("cost_issues", []):
                 st.markdown(f"- {issue}")

def main():
    if "token" not in st.session_state:
        display_login()
    else:
        display_dashboard()

if __name__ == "__main__":
    main()
