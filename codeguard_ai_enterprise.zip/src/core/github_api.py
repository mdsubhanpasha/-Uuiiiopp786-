import os
import requests
from typing import Optional, Dict, Any

class GitHubAPIError(Exception):
    """Exception raised for errors in the GitHub API."""
    pass

def fetch_pr_diff(repo: str, pr_number: int, token: Optional[str] = None) -> str:
    """
    Fetches the diff of a GitHub Pull Request.

    Args:
        repo (str): The repository name in the format 'owner/repo'.
        pr_number (int): The pull request number.
        token (Optional[str]): The GitHub personal access token for authentication. 
                               Defaults to None.

    Returns:
        str: The diff content of the pull request.

    Raises:
        GitHubAPIError: If the request fails.
    """
    url = f"https://api.github.com/repos/{repo}/pulls/{pr_number}"
    
    headers = {
        "Accept": "application/vnd.github.v3.diff"
    }
    
    if token:
        headers["Authorization"] = f"token {token}"
    elif os.environ.get("GITHUB_TOKEN"):
        headers["Authorization"] = f"token {os.environ.get('GITHUB_TOKEN')}"
        
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        raise GitHubAPIError(f"Failed to fetch PR diff: {e}")

def get_pr_details(repo: str, pr_number: int, token: Optional[str] = None) -> Dict[str, Any]:
    """
    Fetches details of a GitHub Pull Request.

    Args:
        repo (str): The repository name in the format 'owner/repo'.
        pr_number (int): The pull request number.
        token (Optional[str]): The GitHub personal access token for authentication.

    Returns:
        Dict[str, Any]: A dictionary containing PR details (title, body, user, etc.).

    Raises:
        GitHubAPIError: If the request fails.
    """
    url = f"https://api.github.com/repos/{repo}/pulls/{pr_number}"
    
    headers = {
        "Accept": "application/vnd.github.v3+json"
    }
    
    if token:
        headers["Authorization"] = f"token {token}"
    elif os.environ.get("GITHUB_TOKEN"):
        headers["Authorization"] = f"token {os.environ.get('GITHUB_TOKEN')}"
        
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise GitHubAPIError(f"Failed to fetch PR details: {e}")
