import os
from typing import Dict, Any
from fpdf import FPDF

class PDFReportGenerator:
    """Class to generate a PDF report from Gemini analysis results."""

    def __init__(self, output_dir: str = "assets"):
        self.output_dir = output_dir
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def generate_report(self, analysis_result: Dict[str, Any], repo: str, pr_number: int) -> str:
        """
        Generates a PDF report based on analysis results.

        Args:
            analysis_result (Dict[str, Any]): The analysis result from Gemini.
            repo (str): GitHub repository name.
            pr_number (int): Pull request number.

        Returns:
            str: Path to the generated PDF file.
        """
        pdf = FPDF()
        pdf.add_page()
        
        # Title
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(200, 10, txt="CodeGuard AI Enterprise - Client Delivery Report", ln=True, align='C')
        
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt=f"Repository: {repo} | PR: #{pr_number}", ln=True, align='C')
        pdf.ln(10)
        
        # Score and Status
        pdf.set_font("Arial", 'B', 14)
        pdf.cell(100, 10, txt=f"Score: {analysis_result.get('score', 'N/A')}/100", ln=False)
        
        status = analysis_result.get('status', 'N/A')
        if "APPROVED" in status:
             pdf.set_text_color(0, 128, 0) # Green
        else:
             pdf.set_text_color(255, 0, 0) # Red
             
        pdf.cell(100, 10, txt=status, ln=True, align='R')
        pdf.set_text_color(0, 0, 0) # Reset to black
        pdf.ln(10)
        
        def add_section(title: str, items: list):
            pdf.set_font("Arial", 'B', 12)
            pdf.cell(200, 10, txt=title, ln=True)
            pdf.set_font("Arial", size=10)
            if not items:
                pdf.cell(200, 10, txt="None detected.", ln=True)
            else:
                for item in items:
                    pdf.multi_cell(0, 8, txt=f"- {item}")
            pdf.ln(5)

        add_section("Security Vulnerabilities", analysis_result.get('security_issues', []))
        add_section("Performance Issues", analysis_result.get('performance_issues', []))
        add_section("Bugs Detected", analysis_result.get('bug_issues', []))
        add_section("Cost Optimization Issues", analysis_result.get('cost_issues', []))

        pdf.set_font("Arial", 'B', 12)
        pdf.cell(200, 10, txt="Line-by-Line Comments", ln=True)
        pdf.set_font("Arial", size=10)
        
        comments = analysis_result.get('comments', [])
        if not comments:
             pdf.cell(200, 10, txt="No specific line comments.", ln=True)
        else:
            for comment in comments:
                 line = comment.get('line', 'General')
                 text = comment.get('comment', '')
                 pdf.multi_cell(0, 8, txt=f"Line/Context {line}: {text}")
                 
        output_file = os.path.join(self.output_dir, f"report_{repo.replace('/', '_')}_pr{pr_number}.pdf")
        pdf.output(output_file)
        
        return output_file
