import os
import json
from typing import Dict, Any, Optional

import google.generativeai as genai
from google.api_core.exceptions import GoogleAPIError

class GeminiAnalyzerError(Exception):
    """Exception raised for errors in the Gemini Analyzer."""
    pass

def analyze_code_diff(diff_content: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    """
    Analyzes a code diff using the Gemini API.

    Args:
        diff_content (str): The code diff to analyze.
        api_key (Optional[str]): The Gemini API key. If not provided, it will try to get it from the GEMINI_API_KEY environment variable.

    Returns:
        Dict[str, Any]: A dictionary containing the analysis results:
            - score (int): Score out of 100.
            - status (str): "DEPLOY: APPROVED" or "DEPLOY: BLOCKED".
            - comments (list): List of line-by-line comments.
            - security_issues (list): List of security vulnerabilities.
            - performance_issues (list): List of performance issues.
            - bug_issues (list): List of bugs.
            - cost_issues (list): List of cost issues.

    Raises:
        GeminiAnalyzerError: If the API request fails or the response is invalid.
    """
    key = api_key or os.environ.get("GEMINI_API_KEY")
    if not key:
        raise GeminiAnalyzerError("Gemini API key not provided or found in environment variables.")

    genai.configure(api_key=key)

    # Use a generic model string, assuming 2.0 Pro or fallback
    model_name = "gemini-2.5-pro" # fallback to a known model if needed. For now let's try gemini-2.5-pro or gemini-pro

    try:
        model = genai.GenerativeModel('gemini-pro') 
    except Exception as e:
        raise GeminiAnalyzerError(f"Failed to initialize model: {e}")

    prompt = f"""
    You are an expert Staff AI Engineer. Analyze the following GitHub Pull Request diff.
    Look for:
    1. Security Vulnerabilities
    2. Performance Issues
    3. Bugs
    4. Cost Issues

    Provide the output strictly as a JSON object with the following structure:
    {{
        "score": <int 0-100>,
        "status": "<DEPLOY: APPROVED or DEPLOY: BLOCKED>",
        "comments": [
            {{"line": <line_number or description>, "comment": "<comment text>"}}
        ],
        "security_issues": ["<issue 1>", "<issue 2>"],
        "performance_issues": ["<issue 1>", "<issue 2>"],
        "bug_issues": ["<issue 1>", "<issue 2>"],
        "cost_issues": ["<issue 1>", "<issue 2>"]
    }}

    If the score is below 70, the status should be "DEPLOY: BLOCKED". Otherwise "DEPLOY: APPROVED".

    Diff:
    {diff_content}
    """

    try:
        response = model.generate_content(prompt)
        text_response = response.text
        
        # Clean up markdown if present
        if text_response.startswith("```json"):
            text_response = text_response[7:-3]
        elif text_response.startswith("```"):
            text_response = text_response[3:-3]
            
        result = json.loads(text_response)
        
        # Basic validation
        required_keys = ["score", "status", "comments", "security_issues", "performance_issues", "bug_issues", "cost_issues"]
        if not all(key in result for key in required_keys):
             raise GeminiAnalyzerError("Response JSON is missing required keys.")

        return result
    except json.JSONDecodeError:
        raise GeminiAnalyzerError("Failed to parse Gemini API response as JSON.")
    except GoogleAPIError as e:
         raise GeminiAnalyzerError(f"Gemini API request failed: {e}")
    except Exception as e:
        raise GeminiAnalyzerError(f"An unexpected error occurred during analysis: {e}")
