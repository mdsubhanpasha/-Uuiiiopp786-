from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import os
import sys

# Add core to path so we can import it
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.github_api import fetch_pr_diff, GitHubAPIError
from core.gemini_analyzer import analyze_code_diff, GeminiAnalyzerError
from core.pdf_generator import PDFReportGenerator

app = FastAPI(
    title="CodeGuard AI Enterprise API",
    description="Enterprise-grade PR analysis using Gemini 2.0 Pro",
    version="1.0.0"
)

# Enable CORS for the Streamlit UI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins, adjust in production
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

class AnalysisRequest(BaseModel):
    repo: str
    pr_number: int
    github_token: Optional[str] = None
    gemini_key: Optional[str] = None

class OAuthLoginRequest(BaseModel):
    github_code: str
    
class RoleAssignmentRequest(BaseModel):
    username: str

@app.get("/")
def read_root() -> Dict[str, str]:
    """Root endpoint to check if API is running."""
    return {"message": "CodeGuard AI Enterprise API is running."}

@app.post("/auth/login")
def github_login(request: OAuthLoginRequest) -> Dict[str, Any]:
    """
    Simulates a GitHub OAuth login and assigns a role.
    In a real application, this would exchange the code for an access token.
    """
    # Simulate fetching user info. We'll assign a role based on a dummy logic
    # or let the user choose in the UI. For this mock, we just return success.
    # The UI will handle the role selection.
    if not request.github_code:
         raise HTTPException(status_code=400, detail="GitHub code is required.")
         
    return {
        "status": "success",
        "message": "Authentication successful (simulated).",
        "token": "dummy_oauth_token_123"
    }

@app.post("/auth/assign_role")
def assign_role(request: RoleAssignmentRequest) -> Dict[str, str]:
    """
    Simulates assigning a role (Dev, QA, Client) to a user based on configuration.
    """
    # Dummy logic to assign role
    role = "Dev"
    if "qa" in request.username.lower():
         role = "QA"
    elif "client" in request.username.lower():
         role = "Client"
         
    return {"username": request.username, "role": role}

@app.post("/analyze")
def analyze_pr(request: AnalysisRequest) -> Dict[str, Any]:
    """
    Fetches a PR diff and analyzes it using Gemini.
    """
    try:
        # 1. Fetch diff
        diff = fetch_pr_diff(repo=request.repo, pr_number=request.pr_number, token=request.github_token)
        
        # 2. Analyze diff
        analysis_result = analyze_code_diff(diff_content=diff, api_key=request.gemini_key)
        
        # 3. Generate PDF
        pdf_gen = PDFReportGenerator(output_dir="assets")
        pdf_path = pdf_gen.generate_report(analysis_result, request.repo, request.pr_number)
        
        return {
            "status": "success",
            "repo": request.repo,
            "pr_number": request.pr_number,
            "analysis": analysis_result,
            "pdf_report_path": pdf_path
        }
    except GitHubAPIError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except GeminiAnalyzerError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")
