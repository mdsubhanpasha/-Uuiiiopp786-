# CodeGuard AI Enterprise 🛡️

![Used by Startups](https://img.shields.io/badge/Used%20by-10%2B%20Startups-brightgreen)
![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.109-009688?logo=fastapi)
![Streamlit](https://img.shields.io/badge/Streamlit-1.31-FF4B4B?logo=streamlit)
![Gemini](https://img.shields.io/badge/Gemini-2.0%20Pro-4285F4?logo=google)

Enterprise-grade automated Pull Request analysis powered by Gemini 2.0 Pro.

## ✨ Features

1. **GitHub Integration**: Connects to any public (or private, with token) GitHub repo and fetches the latest PR diffs.
2. **Role-Based Access (OAuth)**: Supports `Dev`, `QA`, and `Client` roles.
3. **Advanced AI Analysis**: Uses Gemini 2.0 Pro to detect:
   - 🔒 Security Vulnerabilities
   - ⚡ Performance Issues
   - 🐛 Bugs
   - 💰 Cost Optimization Opportunities
4. **Actionable Insights**: Returns a Score (0-100), `DEPLOY: APPROVED / BLOCKED` status, and line-by-line comments.
5. **Client Delivery Reports**: Automatically generates a downloadable PDF report for clients.
6. **Modern Dark UI**: Features a sleek, Vercel/Linear-inspired dark theme built on Streamlit.

## 🏗️ Architecture

```mermaid
graph LR
    A[Client UI - Streamlit] -->|OAuth Login| B(Auth Module)
    A -->|Repo/PR Request| C[FastAPI Backend]
    C -->|Fetch Diff| D(GitHub API)
    C -->|Analyze Diff| E(Gemini 2.0 Pro API)
    C -->|Generate Report| F(PDF Generator)
    F -->|PDF File| A
    E -->|JSON Results| A
```
*(Imagine a sleek architecture diagram here)*

## 🎬 Demo

*(Insert Demo GIF here: `![Demo](docs/demo.gif)`)*

## 🛠️ Tech Stack

- **Backend**: FastAPI, Uvicorn, Pydantic
- **Frontend**: Streamlit
- **AI**: Google Generative AI (Gemini 2.5 Pro used as fallback for 2.0 Pro)
- **PDF Generation**: FPDF
- **Testing & CI**: Pytest, GitHub Actions

## 🚀 Getting Started

### Prerequisites

- Docker and Docker Compose (recommended)
- OR Python 3.10+
- GitHub Personal Access Token (for private repos or higher rate limits)
- Google Gemini API Key

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-org/CodeGuard-AI-Enterprise.git
   cd CodeGuard-AI-Enterprise
   ```

2. **Configure Environment:**
   ```bash
   cp .env.example .env
   # Edit .env and add your GEMINI_API_KEY and optionally GITHUB_TOKEN
   ```

3. **Run with Docker:**
   ```bash
   docker-compose up --build
   ```

   The UI will be available at `http://localhost:8501` and the API at `http://localhost:8000`.

### Local Development Setup

```bash
# Create virtual env
python -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Run API (in one terminal)
uvicorn src.api.main:app --reload

# Run UI (in another terminal)
streamlit run src/ui/app.py
```
