import pytest
import json
from unittest.mock import patch, MagicMock
from src.core.gemini_analyzer import analyze_code_diff, GeminiAnalyzerError

@patch('src.core.gemini_analyzer.genai')
def test_analyze_code_diff_success(mock_genai):
    """Test successful analysis of code diff."""
    mock_model = MagicMock()
    mock_response = MagicMock()
    
    # Mocking the JSON response from Gemini
    expected_result = {
        "score": 90,
        "status": "DEPLOY: APPROVED",
        "comments": [{"line": 10, "comment": "Good job."}],
        "security_issues": [],
        "performance_issues": [],
        "bug_issues": [],
        "cost_issues": []
    }
    mock_response.text = json.dumps(expected_result)
    mock_model.generate_content.return_value = mock_response
    mock_genai.GenerativeModel.return_value = mock_model

    result = analyze_code_diff("some diff content", api_key="dummy_key")
    
    assert result == expected_result
    mock_genai.configure.assert_called_once_with(api_key="dummy_key")

def test_analyze_code_diff_missing_key():
    """Test analysis fails when no API key is provided."""
    # Ensure environment variable is not set for this test
    with patch.dict('os.environ', clear=True):
        with pytest.raises(GeminiAnalyzerError, match="Gemini API key not provided or found in environment variables."):
            analyze_code_diff("some diff")

@patch('src.core.gemini_analyzer.genai')
def test_analyze_code_diff_invalid_json(mock_genai):
    """Test analysis handles invalid JSON response from Gemini."""
    mock_model = MagicMock()
    mock_response = MagicMock()
    mock_response.text = "This is not JSON"
    mock_model.generate_content.return_value = mock_response
    mock_genai.GenerativeModel.return_value = mock_model

    with pytest.raises(GeminiAnalyzerError, match="Failed to parse Gemini API response as JSON."):
         analyze_code_diff("some diff content", api_key="dummy_key")
