import pytest
from unittest.mock import patch, MagicMock
from src.core.github_api import fetch_pr_diff, get_pr_details, GitHubAPIError

@patch('src.core.github_api.requests.get')
def test_fetch_pr_diff_success(mock_get):
    """Test successful fetching of a PR diff."""
    mock_response = MagicMock()
    mock_response.raise_for_status.return_value = None
    mock_response.text = "diff --git a/file b/file"
    mock_get.return_value = mock_response

    diff = fetch_pr_diff("test/repo", 1)
    
    assert diff == "diff --git a/file b/file"
    mock_get.assert_called_once()
    args, kwargs = mock_get.call_args
    assert kwargs["headers"]["Accept"] == "application/vnd.github.v3.diff"

@patch('src.core.github_api.requests.get')
def test_fetch_pr_diff_failure(mock_get):
    """Test failure to fetch a PR diff raises GitHubAPIError."""
    from requests.exceptions import RequestException
    
    mock_get.side_effect = RequestException("Network error")

    with pytest.raises(GitHubAPIError, match="Failed to fetch PR diff: Network error"):
        fetch_pr_diff("test/repo", 1)

@patch('src.core.github_api.requests.get')
def test_get_pr_details_success(mock_get):
    """Test successful fetching of PR details."""
    mock_response = MagicMock()
    mock_response.raise_for_status.return_value = None
    mock_response.json.return_value = {"title": "Test PR"}
    mock_get.return_value = mock_response

    details = get_pr_details("test/repo", 1)
    
    assert details == {"title": "Test PR"}
    mock_get.assert_called_once()
    args, kwargs = mock_get.call_args
    assert kwargs["headers"]["Accept"] == "application/vnd.github.v3+json"
