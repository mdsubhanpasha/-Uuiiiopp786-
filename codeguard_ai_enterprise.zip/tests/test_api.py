import sys
import os
import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

# Ensure the root directory is on the path so we can import src.api.main
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.api.main import app

client = TestClient(app)

def test_read_root():
    """Test the root endpoint."""
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "CodeGuard AI Enterprise API is running."}

def test_github_login_success():
    """Test the simulated GitHub login endpoint."""
    response = client.post("/auth/login", json={"github_code": "some_code"})
    assert response.status_code == 200
    assert response.json() == {
        "status": "success",
        "message": "Authentication successful (simulated).",
        "token": "dummy_oauth_token_123"
    }

def test_github_login_failure():
    """Test login failure when code is missing."""
    response = client.post("/auth/login", json={"github_code": ""})
    assert response.status_code == 400

def test_assign_role():
    """Test role assignment logic."""
    response = client.post("/auth/assign_role", json={"username": "qa_user"})
    assert response.status_code == 200
    assert response.json() == {"username": "qa_user", "role": "QA"}
    
    response2 = client.post("/auth/assign_role", json={"username": "client_abc"})
    assert response2.status_code == 200
    assert response2.json() == {"username": "client_abc", "role": "Client"}

@patch('src.api.main.fetch_pr_diff')
@patch('src.api.main.analyze_code_diff')
@patch('src.api.main.PDFReportGenerator')
def test_analyze_pr_success(mock_pdf_gen_class, mock_analyze, mock_fetch):
    """Test the analyze PR endpoint."""
    # Setup mocks
    mock_fetch.return_value = "dummy diff"
    mock_analyze.return_value = {"score": 95, "status": "DEPLOY: APPROVED"}
    
    mock_pdf_gen_instance = MagicMock()
    mock_pdf_gen_instance.generate_report.return_value = "assets/dummy_report.pdf"
    mock_pdf_gen_class.return_value = mock_pdf_gen_instance

    payload = {
        "repo": "test/repo",
        "pr_number": 1,
        "github_token": "token123",
        "gemini_key": "key123"
    }

    response = client.post("/analyze", json=payload)
    
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["repo"] == "test/repo"
    assert data["analysis"]["score"] == 95
    assert data["pdf_report_path"] == "assets/dummy_report.pdf"
    
    # Verify mock calls
    mock_fetch.assert_called_once_with(repo="test/repo", pr_number=1, token="token123")
    mock_analyze.assert_called_once_with(diff_content="dummy diff", api_key="key123")
    mock_pdf_gen_instance.generate_report.assert_called_once()
